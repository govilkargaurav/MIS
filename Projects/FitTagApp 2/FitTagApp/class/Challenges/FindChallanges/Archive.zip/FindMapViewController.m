//
//  FindMapViewController.m
//  FitTagApp
//
//  Created by apple on 2/25/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "FindMapViewController.h"
#import "FindChallengesViewConroller.h"
@implementation FindMapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //navigation back Button- Arrow
    UIButton *btnback=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnback addTarget:self action:@selector(btnHeaderbackPressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnback setFrame:CGRectMake(0, 0, 40, 44)];
    [btnback setImage:[UIImage imageNamed:@"headerback"] forState:UIControlStateNormal];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithCustomView:btnback ];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    UIButton *btnList=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnList addTarget:self action:@selector(btnListPressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnList setFrame:CGRectMake(0, 0, 40, 44)];
    [btnList setImage:[UIImage imageNamed:@"headerList"] forState:UIControlStateNormal];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:btnList ];
    self.navigationItem.rightBarButtonItem = rightButton;

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(IBAction)btnListPressed:(id)sender{
  // FindMapViewController *findMapViewController = [[FindMapViewController alloc] initWithNibName:@"FindMapViewController" bundle:[NSBundle mainBundle]];
    
    [UIView beginAnimations:@"View Flip" context:nil];
    [UIView setAnimationDuration:0.80];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft 
                           forView:self.navigationController.view cache:NO];
    
    [self.navigationController popViewControllerAnimated:YES];
    [UIView commitAnimations];
}
-(IBAction)btnHeaderbackPressed:(id)sender{
    
    //[self.navigationController popViewControllerAnimated:YES];
    NSArray *array = [self.navigationController viewControllers];
    //NSLog(@"%@",array);
    for(int i=0;i<array.count;i++){
        if([[array objectAtIndex:i] isKindOfClass:[FindChallengesViewConroller class]]){
            
            [self.navigationController popToViewController:[array objectAtIndex:i] animated:YES];
            break;
        }
        
        
    }
}
@end
