//
//  SearchChngCell.m
//  FitTagApp
//
//  Created by apple on 2/20/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "SearchChngCell.h"

@implementation SearchChngCell
@synthesize profilrEgoImageView;
@synthesize lblUserName;
@synthesize lblChallengeName;
@synthesize lblLocation;
@synthesize lblTime;
@synthesize txtViewDescriptionTag;
@synthesize txtViewLikes;
@synthesize btnSeeOlgerComment;
@synthesize teaserEgoImageView;
@synthesize btnLikeChallenge;
@synthesize btnComment;
@synthesize btnReport;
@synthesize btnShare;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *nibArray=[[NSBundle mainBundle]loadNibNamed:@"SearchChngCell" owner:self options:nil];
        self=[nibArray objectAtIndex:0];
    }
    
    return self;
    
}

//-(void)setDict:(NSDictionary *)dictionar
//{
//    
//    if ([dictionar valueForKey:@"urlAvtar"]!=nil)
//    {
//        NSString *strURLnew = [NSString stringWithFormat:@"%@",[dictionar valueForKey:@"urlAvtar"]];
//        teaserEgoImageView.imageURL=[NSURL URLWithString:strURLnew];
//        UIImage *image=teaserEgoImageView.image;
//        teaserEgoImageView.image=image;
//        [teaserEgoImageView setContentMode:UIViewContentModeScaleToFill];
//    }
//    
//}
//
//-(void)setProfileImageDict:(NSDictionary *)dictionary{
//    
//    if ([dictionary valueForKey:@"urlProfileImage"]!=nil)
//    {
//        NSString *strURLnew = [NSString stringWithFormat:@"%@",[dictionary valueForKey:@"urlProfileImage"]];
//        profilrEgoImageView.imageURL=[NSURL URLWithString:strURLnew];
//        UIImage *image=profilrEgoImageView.image;
//        profilrEgoImageView.image=image;
//        [profilrEgoImageView setContentMode:UIViewContentModeScaleToFill];
//    }
//    
//    
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
