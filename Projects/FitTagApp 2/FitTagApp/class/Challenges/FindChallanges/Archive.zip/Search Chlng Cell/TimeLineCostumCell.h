//
//  TimeLineCostumCell.h
//  FitTag
//
//  Created by apple on 3/14/13.
//
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface TimeLineCostumCell : UIViewController

{
    PFObject *objChallengeInfo;
    PFUser *objUserInfo;
    PFUser *userForLike;
    NSMutableArray *arrLikesName;
    NSMutableArray *arrLikeUserId;
    NSString *StrLikesRow;
   
    IBOutlet UIImageView *profilrEgoImageView;
    IBOutlet UIButton *lblUserName;
    IBOutlet UILabel *lblChallengeName;
    IBOutlet UILabel *lblLocation;
    IBOutlet UILabel *lblTime;
    IBOutlet UITextView *txtViewDescriptionTag;
    IBOutlet UITextView *txtViewLikes;
    IBOutlet UIButton *btnSeeOlgerComment;
    IBOutlet UIImageView *teaserEgoImageView;
    IBOutlet UIButton *btnLikeChallenge;
    IBOutlet UIButton *btnComment;
    IBOutlet UIButton *btnReport;
    IBOutlet UIButton *btnShare;
    IBOutlet UILabel *lblComment1;
    IBOutlet UILabel *lblComment2;
    IBOutlet UILabel *lblComment3;
    IBOutlet UILabel *lblComment4;
//    IBOutlet UIButton *lbluserName1;
//    IBOutlet UIButton *lbluserName2;
//    IBOutlet UIButton *lbluserName3;
//    IBOutlet UIButton *lbluserName4;
    NSArray *arrUserDataClass;
    int indexpathRow;
    
}
@property (nonatomic, retain) IBOutlet UIButton *btnuserName1;
@property (nonatomic, retain) IBOutlet UIButton *btnuserName2;
@property (nonatomic, retain) IBOutlet UIButton *btnuserName3;
@property (nonatomic, retain) IBOutlet UIButton *btnuserName4;

@property (nonatomic, retain) IBOutlet UILabel *lblComment1;
@property (nonatomic, retain) IBOutlet UILabel *lblComment2;
@property (nonatomic, retain) IBOutlet UILabel *lblComment3;
@property (nonatomic, retain) IBOutlet UILabel *lblComment4;

@property(nonatomic,retain)   IBOutlet UIButton *btnSeeOlgerComment;
//@property (strong, nonatomic) IBOutlet UIImageView *profilrEgoImageView;
//@property (strong, nonatomic) IBOutlet UIButton *lblUserName;
//@property (strong, nonatomic) IBOutlet UILabel *lblChallengeName;
//@property (strong, nonatomic) IBOutlet UILabel *lblLocation;
//@property (strong, nonatomic) IBOutlet UILabel *lblTime;
//@property (strong, nonatomic) IBOutlet UITextView *txtViewDescriptionTag;
@property (strong, nonatomic) IBOutlet UITextView *txtViewLikes;
//@property (strong, nonatomic) IBOutlet UIButton *btnSeeOlgerComment;
//@property (strong, nonatomic) IBOutlet UIImageView *teaserEgoImageView;
@property (strong, nonatomic) IBOutlet UIButton *btnLikeChallenge;
@property (strong, nonatomic) IBOutlet UIButton *btnComment;
//@property (strong, nonatomic) IBOutlet UIButton *btnReport;
//@property (strong, nonatomic) IBOutlet UIButton *btnShare;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andD:(PFObject *)dVal row:(int)rowIndexPath userData:(NSMutableArray *)arrUserData;

//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andD:(PFObject *)dVal;// name:(NSString *)strName index:(NSString *)StrLikesName;

-(UIButton *)likebtnCreate:(NSString*)strUserName;
@end
