//
//  TimeLineCostumCell.m
//  FitTag
//
//  Created by apple on 3/14/13.

#import "TimeLineCostumCell.h"
#import "UIImageView+WebCache.h"
#import "CommentViewController.h"
#import "GlobalClass.h"
#import <MediaPlayer/MediaPlayer.h>

@implementation TimeLineCostumCell

@synthesize btnuserName1,btnuserName2,btnuserName3,btnuserName4;
@synthesize lblComment1,lblComment2,lblComment3,lblComment4;
//@synthesize profilrEgoImageView;
//@synthesize lblUserName;
//@synthesize lblChallengeName;
//@synthesize lblLocation;
//@synthesize lblTime;
//@synthesize txtViewDescriptionTag;
@synthesize txtViewLikes;
//@synthesize btnSeeOlgerComment;
//@synthesize teaserEgoImageView;
@synthesize btnLikeChallenge;
@synthesize btnComment;
//@synthesize btnReport;
//@synthesize btnShare;
@synthesize btnSeeOlgerComment;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andD:(PFObject *)dVal  row:(int)rowIndexPath userData:(NSMutableArray *)arrUserData
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization

       // arrLikesName=[[NSMutableArray alloc]init];
      //  arrLikeUserId=[[NSMutableArray alloc]init];
        objChallengeInfo=dVal;
        //StrLikesRow=StrLikesName;
        indexpathRow=rowIndexPath;
        arrUserDataClass=arrUserData;
    }

    return self;

}


- (void)viewDidLoad
{
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    objUserInfo=[objChallengeInfo objectForKey:@"userId"];    
    PFFile *uesrProfileImage = [objUserInfo objectForKey:@"userPhoto"];
    PFFile *teaserImage = [objChallengeInfo objectForKey:@"teaserfile"];
    PFFile *teaservideo = [objChallengeInfo objectForKey:@"mediafile"];

    UIWebView  *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, 303, 172 )];

    webView.autoresizesSubviews = YES;
    webView.autoresizingMask=(UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth);
    
    NSString *videoUrl = @"http://km.support.apple.com/library/APPLE/APPLECARE_ALLGEOS/HT1211/sample_iTunes.mov";
   // NSString *youTubeHTMLTemplate = @"<html><body style=\"margin:0;padding:0;\"><iframe class=\"youtube-player\" type=\"text/html\" width=\"%f\" height=\"%f\" src=\"%@\" frameborder=\"0\" allowfullscreen></iframe></body></html>";
   //  NSString * finalHtml = [NSString stringWithFormat:youTubeHTMLTemplate, @"303" , @"172", [teaservideo url]];
    
  //  NSString *htmlString = [NSString stringWithFormat:@"<html><head><meta name = \"viewport\" content = \"initial-scale = 1.0, user-scalable = no, width = 212\"/></head><body style=\"background:#F00;margin-top:0px;margin-left:0px\"><div><object width=\"303\" height=\"172\"><param name=\"movie\" value=\"%@\"></param><param name=\"wmode\" value=\"transparent\"></param><embed src=\"%@\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" width=\"303\" height=\"172\"></embed></object></div></body></html>",videoUrl,videoUrl]    ;
  //Final
    /*
    NSString *embedHTML = @"\
    <html><head>\
    <style type=\"text/css\">\
    body {\
    background-color: white;\
    color: white;\
    }\
    </style>\
    </head><body style=\"margin:0\">\
    <embed id=\"yt\" src=\"%@\" type=\"application/x-shockwave-flash\" \
    width=\"%0.0f\" height=\"%0.0f\"></embed>\
    </body></html>";
    
    NSString *html = [NSString stringWithFormat:embedHTML,videoUrl, 303.0, 172.0];
    [webView loadHTMLString:html baseURL:nil];
   // [teaserEgoImageView addSubview:webView];
    */
//    NSURL *fileURL = [NSURL URLWithString:videoUrl];
//    
//   MPMoviePlayerController* moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL URLWithString:videoUrl]]; 
//    [moviePlayerController.view setFrame:CGRectMake(0, 0, 303, 172)]; 
//    //[self.view addSubview:moviePlayerController.view];  
//    [moviePlayerController setShouldAutoplay:YES];//or yes if you want it to
//    [moviePlayerController prepareToPlay];
//    [moviePlayerController play]; 

    // [teaserEgoImageView addSubview:moviePlayerController.view];
    
    [profilrEgoImageView setImageWithURL:[NSURL URLWithString:[uesrProfileImage url]] placeholderImage:[UIImage imageNamed:@"nothing.png"]];
    profilrEgoImageView.layer.masksToBounds = YES;
    profilrEgoImageView.clipsToBounds=YES;
    [profilrEgoImageView.layer setBorderWidth:1.5];
    [profilrEgoImageView.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [profilrEgoImageView.layer setCornerRadius:7.0];
    
    [teaserEgoImageView setImageWithURL:[NSURL URLWithString:[teaserImage url]] placeholderImage:[UIImage imageNamed:@"TeaserBG.png"]];
    
    teaserEgoImageView.layer.cornerRadius = 10.0;
    teaserEgoImageView.layer.masksToBounds = YES;
    teaserEgoImageView.clipsToBounds=YES;
   // [self.view setNeedsLayout];
    
    //lblUserName.titleLabel.text=[objUserInfo username];
    [lblUserName setTitle:[objUserInfo username] forState:UIControlStateHighlighted];
    [lblUserName setTitle:[objUserInfo username] forState:UIControlStateNormal];
    lblChallengeName.text=[objChallengeInfo objectForKey:@"challengeName"];
    lblLocation.text=[objChallengeInfo objectForKey:@"locationName"];
    txtViewDescriptionTag.text=[objChallengeInfo objectForKey:@"tags"];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MM dd,yyyy,hh:mm"];
    NSString *result = [formatter stringFromDate:[objChallengeInfo createdAt]];
    NSArray *arrTime=[result componentsSeparatedByString:@","];
    
    
    //time differnce counting
    
    NSString* strTime = [arrTime lastObject];
    strTime = [strTime stringByReplacingOccurrencesOfString:@"Z" withString:@""];
    
    NSDateFormatter* df = [[NSDateFormatter alloc]init];
    
   // [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    
    [df setDateFormat:@"MM dd,yyyy,hh:mm"];
    
    NSDate* dateNews = [objChallengeInfo createdAt];
    
    NSDate* currentDate = [NSDate date];
    
    [df setDateFormat:@"MM dd,yyyy,hh:mm"];
    
    NSTimeInterval secondsBetween = [currentDate timeIntervalSinceDate:dateNews];
    
    int hours = (int)secondsBetween / 3600;
    int mins = (secondsBetween - (hours*3600)) / 60;
    
    NSString* strTimeInt = @"";
    
    if(hours > 0)
    {
        if(hours >= 24)
        {
            int daysNos = hours/24;
            if(daysNos==1)
            {
                strTimeInt = [NSString stringWithFormat:@"%@ day ago",@"1"];
            }
            else
            {
                if(daysNos >= 7)
                {
                    strTimeInt = [NSString stringWithFormat:@"1 week ago"];
                }
                else
                {
                    strTimeInt = [NSString stringWithFormat:@"%d day ago",daysNos];
                }
                
            }
        }
        else if(hours < 24)
        {
            if(hours == 1)
            {
                strTimeInt = [NSString stringWithFormat:@"%d hour ago",hours];
            }
            else
            {
                strTimeInt = [NSString stringWithFormat:@"%d hours ago",hours];
            }
        }
    }
    else if(hours == 0)
    {
        if(mins == 1)
        {
            strTimeInt = [NSString stringWithFormat:@"%d min ago",mins];
        }
        else
        {
            if(mins > 0 && mins <= 15)
            {
                strTimeInt = [NSString stringWithFormat:@"%d mins ago",15];
            }
            else if(mins > 15 && mins <= 30)
            {
                strTimeInt = [NSString stringWithFormat:@"%d mins ago",15];
            }
            else if(mins > 30 && mins <= 45)
            {
                strTimeInt = [NSString stringWithFormat:@"%d mins ago",30];
            }
            else if(mins > 45 && mins < 60)
            {
                strTimeInt = [NSString stringWithFormat:@"%d mins ago",45];
            }
            else if(mins >= 60)
            {
                strTimeInt = [NSString stringWithFormat:@"%@ hours ago",@"1"];
            }
        }
    }
    lblTime.text=strTimeInt;
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    [arr addObjectsFromArray:[objChallengeInfo objectForKey:@"likesAndComments"]];
//    if ([arr count]>0) {
//        for (int i=0; i<[arr count]-1; i++) {
//            PFObject *objActivity=[arr objectAtIndex:i];
//            PFUser *user=[objActivity objectForKey:@"userId"];
//            
//            if([txtViewLikes.text length] > 0){
//                
//                //NSLog(@"%@",[user username]);
//                txtViewLikes.text = [[NSString stringWithFormat:@"%@,%@",[user username],txtViewLikes.text] stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
//            }else{
//                //NSLog(@"%@",[user username]);
//                
//                txtViewLikes.text = [[NSString stringWithFormat:@"%@",[user username]] stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
//            }
//            
//            if ([[user username] isEqualToString:[[PFUser currentUser] username]]) {
//                
//                IsLiked =YES;
//                
//            }
//        
//        }
//        
//    }
//    
    if ([arr count]>0) {
        switch ([arr count]) {
           
            case 1:{
                PFObject *objActivity=[arr objectAtIndex:0];
                PFUser *user=[objActivity objectForKey:@"userId"];

                txtViewLikes.text = [[NSString stringWithFormat:@"%@ %@",[user username],txtViewLikes.text] stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];

            }
            break;

            case 2:{
                PFObject *objActivity=[arr objectAtIndex:0];
                PFUser *user=[objActivity objectForKey:@"userId"];
           
                PFObject *objActivity2=[arr objectAtIndex:1];
                PFUser *user2=[objActivity2 objectForKey:@"userId"];
                
                txtViewLikes.text = [[NSString stringWithFormat:@"%@,%@ %@",[user username],[user2 username],txtViewLikes.text] stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];

            }
            
            break;
            case 3:{
                PFObject *objActivity=[arr objectAtIndex:0];
                PFUser *user=[objActivity objectForKey:@"userId"];
                
                PFObject *objActivity2=[arr objectAtIndex:1];
                PFUser *user2=[objActivity2 objectForKey:@"userId"];
                
                PFObject *objActivity3=[arr objectAtIndex:2];
                PFUser *user3=[objActivity3 objectForKey:@"userId"];
                
                txtViewLikes.text = [[NSString stringWithFormat:@"%@,%@,%@ %@",[user username],[user2 username],[user3 username],txtViewLikes.text] stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
               
                
            }
                break;
            default:{
                
                PFObject *objActivity=[arr objectAtIndex:0];
                PFUser *user=[objActivity objectForKey:@"userId"];
                
                PFObject *objActivity2=[arr objectAtIndex:1];
                PFUser *user2=[objActivity2 objectForKey:@"userId"];
                
                PFObject *objActivity3=[arr objectAtIndex:2];
                PFUser *user3=[objActivity3 objectForKey:@"userId"];
                
                txtViewLikes.text = [[NSString stringWithFormat:@"%@,%@,%@ %@ %@",[user username],[user2 username],[user3 username],[NSString stringWithFormat:@"& %d people",arr.count-3],txtViewLikes.text] stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
            
            }
                
                break;
        }      
        
    }else{
        txtViewLikes.text=@"Like this.";
    }

    NSMutableArray *arrComments=[[NSMutableArray alloc]init];
    [arrComments addObjectsFromArray:[objChallengeInfo objectForKey:@"onlyComments"]];
    
    [btnSeeOlgerComment setTitle:[NSString stringWithFormat:@"See %d older comments",arrComments.count] forState:UIControlStateNormal];
    
    if ([arrComments count]>0) {

        for (int i=0; i<[arrComments count]; i++) {
            PFObject *objActivity=[arrComments objectAtIndex:i];
            PFUser *user=[objActivity objectForKey:@"userId"];
            CGSize stringsize = [[user username] sizeWithFont:[UIFont boldSystemFontOfSize:12]];
            if (i==0) {
              
                btnuserName1.frame=CGRectMake(btnuserName1.frame.origin.x,btnuserName1.frame.origin.y,stringsize.width, stringsize.height);
                [btnuserName1 setTitle:[user username] forState:UIControlStateNormal];
                lblComment1.frame=CGRectMake(btnuserName1.frame.origin.x+stringsize.width+5,lblComment1.frame.origin.y,210-btnuserName1.frame.size.width, lblComment1.frame.size.height);
                [lblComment1 setText:[objActivity objectForKey:@"CommentText"]];
                
//                UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(97, initialY, 100, 13)];   
//                button = [UIButton buttonWithType:UIButtonTypeCustom];
//                [button setFont:[UIFont boldSystemFontOfSize:11]];
//                [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//                [button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
//                button.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;
//                [button setTitle:strUserName forState:UIControlStateNormal ];
//                button.contentMode = UIViewContentModeLeft;
//                CGSize stringsize = [strUserName sizeWithFont:[UIFont systemFontOfSize:12]]; 
//                //or whatever font you're using
//                [button setFrame:CGRectMake(94,initialY,stringsize.width, stringsize.height)];
//                //Comment
//               
//                UILabel *lblComment=[[UILabel alloc]initWithFrame:CGRectMake(button.frame.size.width+100, initialY, 100, 20)];
//                [lblComment setFont:[UIFont boldSystemFontOfSize:11]];
//                [lblComment setText:strComment];
//                CGSize stringCommentsize = [strComment sizeWithFont:[UIFont systemFontOfSize:12]];
//                [lblComment setTextColor:[UIColor blackColor]];
//                [lblComment setFrame:CGRectMake(lblComment.frame.origin.x,lblComment.frame.origin.y,stringCommentsize.width, stringCommentsize.height)];
//                
//                [self.view addSubview:button];
//                [self.view addSubview:lblComment];
//                
//                initialY=initialY+15;
//                
 
            }
            else if(i==1){
                
//                UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(97, initialY, 100, 13)];   
//                button = [UIButton buttonWithType:UIButtonTypeCustom];
//                [button setFont:[UIFont boldSystemFontOfSize:11]];
//                [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//                [button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
//                button.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;
//                [button setTitle:strUserName forState:UIControlStateNormal ];
//                button.contentMode = UIViewContentModeLeft;
//                CGSize stringsize = [strUserName sizeWithFont:[UIFont systemFontOfSize:12]]; 
//                //or whatever font you're using
//                [button setFrame:CGRectMake(94,initialY,stringsize.width, stringsize.height)];
//                //Comment
//               
//                UILabel *lblComment=[[UILabel alloc]initWithFrame:CGRectMake(button.frame.size.width+100, initialY, 100, 20)];
//                [lblComment setFont:[UIFont boldSystemFontOfSize:11]];
//                [lblComment setText:strComment];
//                CGSize stringCommentsize = [strComment sizeWithFont:[UIFont systemFontOfSize:12]];
//                [lblComment setTextColor:[UIColor blackColor]];
//                [lblComment setFrame:CGRectMake(lblComment.frame.origin.x,lblComment.frame.origin.y,stringCommentsize.width, stringCommentsize.height)];
//                
//                [self.view addSubview:button];
//                [self.view addSubview:lblComment];
//                 initialY=initialY+15;
                btnuserName2.Frame=CGRectMake(btnuserName2.frame.origin.x,btnuserName2.frame.origin.y,stringsize.width, stringsize.height);
                [btnuserName2 setTitle:[user username] forState:UIControlStateNormal];
                lblComment2.frame=CGRectMake(btnuserName2.frame.origin.x+stringsize.width+5,lblComment2.frame.origin.y,210-btnuserName2.frame.size.width, lblComment2.frame.size.height);
                [lblComment2 setText:[objActivity objectForKey:@"CommentText"]];

            }else if(i==2){
//                UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(97, initialY, 100, 13)];   
//                button = [UIButton buttonWithType:UIButtonTypeCustom];
//                [button setFont:[UIFont boldSystemFontOfSize:11]];
//                [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//                [button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
//                button.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;
//                [button setTitle:strUserName forState:UIControlStateNormal ];
//                button.contentMode = UIViewContentModeLeft;
//                CGSize stringsize = [strUserName sizeWithFont:[UIFont systemFontOfSize:12]]; 
//                //or whatever font you're using
//                [button setFrame:CGRectMake(94,initialY,stringsize.width, stringsize.height)];
//                //Comment
//              
//                UILabel *lblComment=[[UILabel alloc]initWithFrame:CGRectMake(button.frame.size.width+100, initialY, 100, 20)];
//                [lblComment setFont:[UIFont boldSystemFontOfSize:11]];
//                [lblComment setText:strComment];
//                CGSize stringCommentsize = [strComment sizeWithFont:[UIFont systemFontOfSize:12]];
//                [lblComment setTextColor:[UIColor blackColor]];
//                [lblComment setFrame:CGRectMake(lblComment.frame.origin.x,lblComment.frame.origin.y,stringCommentsize.width, stringCommentsize.height)];
//                
//                [self.view addSubview:button];
//                [self.view addSubview:lblComment];
//                initialY=initialY+15;
                btnuserName3.Frame=CGRectMake(btnuserName3.frame.origin.x,btnuserName3.frame.origin.y,stringsize.width, stringsize.height);
            
                [btnuserName3 setTitle:[user username] forState:UIControlStateNormal];
                lblComment3.frame=CGRectMake(btnuserName3.frame.origin.x+stringsize.width+5,lblComment3.frame.origin.y,210-btnuserName3.frame.size.width, lblComment3.frame.size.height);
                [lblComment3 setText:[objActivity objectForKey:@"CommentText"]];
                
            }else if(i==3){
//                UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(97, initialY, 100, 13)];   
//                button = [UIButton buttonWithType:UIButtonTypeCustom];
//                [button setFont:[UIFont boldSystemFontOfSize:11]];
//                [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//                [button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
//                button.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;
//                [button setTitle:strUserName forState:UIControlStateNormal ];
//                button.contentMode = UIViewContentModeLeft;
//                CGSize stringsize = [strUserName sizeWithFont:[UIFont systemFontOfSize:12]]; 
//                //or whatever font you're using
//                [button setFrame:CGRectMake(94,initialY,stringsize.width, stringsize.height)];
//                //Comment
//               
//                UILabel *lblComment=[[UILabel alloc]initWithFrame:CGRectMake(button.frame.size.width+100, initialY, 100, 20)];
//                [lblComment setFont:[UIFont boldSystemFontOfSize:11]];
//                [lblComment setText:strComment];
//                CGSize stringCommentsize = [strComment sizeWithFont:[UIFont systemFontOfSize:12]];
//                [lblComment setTextColor:[UIColor blackColor]];
//                [lblComment setFrame:CGRectMake(lblComment.frame.origin.x,lblComment.frame.origin.y,stringCommentsize.width, stringCommentsize.height)];
//                
//                [self.view addSubview:button];
//                [self.view addSubview:lblComment];
//                initialY=initialY+15;
                
                btnuserName4.Frame=CGRectMake(btnuserName4.frame.origin.x,btnuserName4.frame.origin.y,stringsize.width, stringsize.height);
                [btnuserName4 setTitle:[user username] forState:UIControlStateNormal];
                lblComment4.frame=CGRectMake(btnuserName4.frame.origin.x+stringsize.width+5,lblComment4.frame.origin.y,210-btnuserName4.frame.size.width, lblComment4.frame.size.height);

                [lblComment4 setText:[objActivity objectForKey:@"CommentText"]];
                
            }else{
                break;
            }
            
        }
    }
    
    [txtViewLikes setTag:indexpathRow+1];
    [btnLikeChallenge setTag:indexpathRow+1];
    [btnComment setTag:indexpathRow+1];
    [btnSeeOlgerComment setTag:indexpathRow+1];
    
    //Buttons for UserName Display
    [btnuserName1 setTag:(indexpathRow+1)+111];
    [btnuserName2 setTag:(indexpathRow+1)+112];
    [btnuserName3 setTag:(indexpathRow+1)+113];
    [btnuserName4 setTag:(indexpathRow+1)+114];
    
    //Lable for Comment Display
    [lblComment1 setTag:(indexpathRow+1)+211];
    [lblComment2 setTag:(indexpathRow+1)+212];
    [lblComment3 setTag:(indexpathRow+1)+213];
    [lblComment4 setTag:(indexpathRow+1)+214];
    
//    btnLikeChallenge.frame=CGRectMake(btnLikeChallenge.frame.origin.x, 396, btnLikeChallenge.frame.size.width, btnLikeChallenge.frame.size.height);
//    btnComment.frame=CGRectMake(btnComment.frame.origin.x, 403, btnComment.frame.size.width, btnComment.frame.size.height);
//    btnShare.frame=CGRectMake(btnShare.frame.origin.x, 401, btnShare.frame.size.width, btnShare.frame.size.height);
//    btnReport.frame=CGRectMake(btnReport.frame.origin.x,408, btnReport.frame.size.width, btnReport.frame.size.height);

    
    if(arrComments.count==0){
        btnLikeChallenge.frame=CGRectMake(btnLikeChallenge.frame.origin.x, btnLikeChallenge.frame.origin.y-50, btnLikeChallenge.frame.size.width, btnLikeChallenge.frame.size.height);
        btnComment.frame=CGRectMake(btnComment.frame.origin.x, btnComment.frame.origin.y-50, btnComment.frame.size.width, btnComment.frame.size.height);
        btnShare.frame=CGRectMake(btnShare.frame.origin.x, btnShare.frame.origin.y-50, btnShare.frame.size.width, btnShare.frame.size.height);
        btnReport.frame=CGRectMake(btnReport.frame.origin.x, btnReport.frame.origin.y-50, btnReport.frame.size.width, btnReport.frame.size.height);
        
    }else if(arrComments.count==1){
        btnLikeChallenge.frame=CGRectMake(btnLikeChallenge.frame.origin.x, btnLikeChallenge.frame.origin.y-35, btnLikeChallenge.frame.size.width, btnLikeChallenge.frame.size.height);
        btnComment.frame=CGRectMake(btnComment.frame.origin.x, btnComment.frame.origin.y-35, btnComment.frame.size.width, btnComment.frame.size.height);
        btnShare.frame=CGRectMake(btnShare.frame.origin.x, btnShare.frame.origin.y-35, btnShare.frame.size.width, btnShare.frame.size.height);
        btnReport.frame=CGRectMake(btnReport.frame.origin.x, btnReport.frame.origin.y-35, btnReport.frame.size.width, btnReport.frame.size.height);
    }else if(arrComments.count==2){
        btnLikeChallenge.frame=CGRectMake(btnLikeChallenge.frame.origin.x, btnLikeChallenge.frame.origin.y-25, btnLikeChallenge.frame.size.width, btnLikeChallenge.frame.size.height);
        btnComment.frame=CGRectMake(btnComment.frame.origin.x, btnComment.frame.origin.y-25, btnComment.frame.size.width, btnComment.frame.size.height);
        btnShare.frame=CGRectMake(btnShare.frame.origin.x, btnShare.frame.origin.y-25, btnShare.frame.size.width, btnShare.frame.size.height);
        btnReport.frame=CGRectMake(btnReport.frame.origin.x, btnReport.frame.origin.y-25, btnReport.frame.size.width, btnReport.frame.size.height);

    }else if(arrComments.count==3){
        btnLikeChallenge.frame=CGRectMake(btnLikeChallenge.frame.origin.x, btnLikeChallenge.frame.origin.y-10, btnLikeChallenge.frame.size.width, btnLikeChallenge.frame.size.height);
        btnComment.frame=CGRectMake(btnComment.frame.origin.x, btnComment.frame.origin.y-10, btnComment.frame.size.width, btnComment.frame.size.height);
        btnShare.frame=CGRectMake(btnShare.frame.origin.x, btnShare.frame.origin.y-10, btnShare.frame.size.width, btnShare.frame.size.height);
        btnReport.frame=CGRectMake(btnReport.frame.origin.x, btnReport.frame.origin.y-10, btnReport.frame.size.width, btnReport.frame.size.height);
        
    }else if(arrComments.count>=4){
        
        btnLikeChallenge.frame=CGRectMake(btnLikeChallenge.frame.origin.x, 396, btnLikeChallenge.frame.size.width, btnLikeChallenge.frame.size.height);
        btnComment.frame=CGRectMake(btnComment.frame.origin.x, 403, btnComment.frame.size.width, btnComment.frame.size.height);
        btnShare.frame=CGRectMake(btnShare.frame.origin.x, 401, btnShare.frame.size.width, btnShare.frame.size.height);
        btnReport.frame=CGRectMake(btnReport.frame.origin.x,408, btnReport.frame.size.width, btnReport.frame.size.height);
        
        
    }
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"CommentBackAction" object:nil];
    
    //Older Comment Button
   
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UIButton *)likebtnCreate:(NSString*)strUserName{
//    
//    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(97, 320, 100, 13)];   
//    button = [UIButton buttonWithType:UIButtonTypeCustom];
//   [button setFont:[UIFont boldSystemFontOfSize:11]];
//    [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
//    button.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;
//   [button setTitle:strUserName forState:UIControlStateNormal ];
//    button.contentMode = UIViewContentModeLeft;
//    CGSize stringsize = [strUserName sizeWithFont:[UIFont systemFontOfSize:12]]; 
//    //or whatever font you're using
//   [button setFrame:CGRectMake(94,320,stringsize.width, stringsize.height)];
//    //Comment
//
//    UILabel *lblComment=[[UILabel alloc]initWithFrame:CGRectMake(button.frame.size.width+100, 320, 100, 20)];
//    [lblComment setFont:[UIFont boldSystemFontOfSize:11]];
//    [lblComment setText:strComment];
//     CGSize stringCommentsize = [strComment sizeWithFont:[UIFont systemFontOfSize:12]];
//    [lblComment setTextColor:[UIColor blackColor]];
//    [lblComment setFrame:CGRectMake(lblComment.frame.origin.x,lblComment.frame.origin.y,stringCommentsize.width, stringCommentsize.height)];
//    
//    [self.view addSubview:button];
//    [self.view addSubview:lblComment];
//
//    
//    return nil;
//    
    return nil;
}

- (void)viewDidUnload {
    btnuserName1 = nil;
    btnuserName2 = nil;
    btnuserName3 = nil;
    btnuserName4 = nil;
 
    lblComment1 = nil;
    lblComment2 = nil;
    lblComment3 = nil;
    lblComment4 = nil;
    [super viewDidUnload];
}
@end
