//
//  TimeLineViewController.h
//  FitTagApp
//
//  Created by apple on 2/19/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>
#import "SettingViewController.h"
#import "FindChallengesViewConroller.h"

#import "ActivityViewController.h"
@interface TimeLineViewController : UIViewController<UINavigationBarDelegate,UIWebViewDelegate>
{
    ActivityViewController *activtyVC;
    NSMutableIndexSet *indexes;
}
@property (strong, nonatomic) IBOutlet UITableView *tblTimeline;
@property (strong, nonatomic) IBOutlet UIView *viewHome;
@property(nonatomic)bool isOpen;
- (IBAction)btnFindPressed:(id)sender;
- (IBAction)btnCreatePressed:(id)sender;
- (IBAction)btnTblRefreshPressed:(id)sender;
-(void)setNavigationComponent;
-(void)viewHomeOpenAnim;
-(void)viewHomeCloseAnim;
- (IBAction)btnHomePressed:(id)sender;
- (IBAction)btnSettingPressed:(id)sender;
- (IBAction)btnActivityPressed:(id)sender;
@end
