//
//  TimeLineViewController.m
//  FitTagApp
//
//  Created by apple on 2/19/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "TimeLineViewController.h"
#import "ProfileViewController.h"
#import "ActivityViewController.h"
#import "CommentViewController.h"
#import "CreateChlng1ViewController.h"


#import "SearchChngCell.h"



#define kStringArray [NSArray arrayWithObjects:@"Home", @"Profile",@"Activity",@"Setting", nil]
@implementation TimeLineViewController

@synthesize tblTimeline;
@synthesize viewHome;
@synthesize isOpen;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
   
    
    [super viewDidLoad];
 
//    // Do any additional setup after loading the view from its nib.
//        UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"Profile " 
//                                                                    style:UIBarButtonItemStylePlain target:self action:@selector(btnProfileAction:)];
//    self.navigationItem.leftBarButtonItem = leftButton;
//    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"Setting " 
//                                                                    style:UIBarButtonItemStylePlain target:self action:@selector(btnSettingAction:)];
//    self.navigationItem.rightBarButtonItem = rightButton;
    [self setNavigationComponent];
    isOpen=NO;
}
-(void)viewWillDisappear:(BOOL)animated{

    if(self.viewHome.frame.origin.y==44){
        [self viewHomeCloseAnim];
    
    }
   
}

- (void)viewDidUnload
{
    [self setTblTimeline:nil];
    [self setViewHome:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark- TableView Delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 50;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cell_%d_%d",indexPath.section,indexPath.row];
    
    SearchChngCell *TblSearchChngCell;
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        NSLog(@"Cell Create at index Path %d",indexPath.row);
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
        TblSearchChngCell =[[SearchChngCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        TblSearchChngCell.tag=111;

//        NSString *embedHTML = @"\
//        <html><head>\
//        <style type=\"text/css\">\
//        body {\
//        background-color: white;\
//        color: white;\
//        }\
//        </style>\
//        </head><body style=\"margin:0\">\
//        <embed id=\"yt\" src=\"http://km.support.apple.com/library/APPLE/APPLECARE_ALLGEOS/HT1211/sample_iTunes.mov\" type=\"application/x-shockwave-mp4\" \
//        width=\"%0.0f\" height=\"%0.0f\"></embed>\
//        </body></html>";
//        
//        UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(12.0, 37.0, 300.0, 172.0)];
//        webView.delegate=self;
//        [webView setOpaque:NO];
//        webView.backgroundColor=[UIColor whiteColor];
//        webView.inputView.backgroundColor=[UIColor whiteColor];
//        NSString *html = [NSString stringWithFormat:embedHTML, webView.frame.size.width, webView.frame.size.height];
//        [webView loadHTMLString:html baseURL:nil];
//        [TblSearchChngCell addSubview:webView];
        
        [cell.contentView addSubview:TblSearchChngCell];

    }
    
//   NSString *CellIdentifier = [NSString stringWithFormat:@"Cell_%d_%d",indexPath.section,indexPath.row];
//    SearchChngCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    if (cell == nil) {
//        NSLog(@"Cell Create at index Path %d",indexPath.row);
//        cell = [[SearchChngCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
//        if (![indexes containsIndex:indexPath.row]) {
//            [indexes addIndex:indexPath.row];
//            NSLog(@"CellIdentifier == >> %@",CellIdentifier);
//            NSString *embedHTML = @"\
//            <html><head>\
//            <style type=\"text/css\">\
//            body {\
//            background-color: white;\
//            color: white;\
//            }\
//            </style>\
//            </head><body style=\"margin:0\">\
//            <embed id=\"yt\" src=\"http://km.support.apple.com/library/APPLE/APPLECARE_ALLGEOS/HT1211/sample_iTunes.mov\" type=\"application/x-shockwave-mp4\" \
//            width=\"%0.0f\" height=\"%0.0f\"></embed>\
//            </body></html>";
//            
//            UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(12.0, 37.0, 300.0, 172.0)];
//            webView.delegate=self;
//            [webView setOpaque:NO];
//            webView.backgroundColor=[UIColor whiteColor];
//            webView.inputView.backgroundColor=[UIColor whiteColor];
//            NSString *html = [NSString stringWithFormat:embedHTML, webView.frame.size.width, webView.frame.size.height];
//            [webView loadHTMLString:html baseURL:nil];
//            [cell addSubview:webView];
//        }
//        
//       
//
//    }
//   
    
    
    //--
     [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 390;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"didSelectRowAtIndexPath");
    CommentViewController *commentVC=[[CommentViewController alloc]initWithNibName:@"CommentViewController" bundle:nil];
    commentVC.title=@"Comment";
    [self.navigationController pushViewController:commentVC animated:YES];
    
} 
#pragma mark- Button Actions

- (IBAction)btnFindPressed:(id)sender {
    FindChallengesViewConroller *findCalngVC=[[FindChallengesViewConroller alloc]initWithNibName:@"FindChallengesViewConroller" bundle:nil];
    //    UINavigationController *navContrlVC=[[UINavigationController alloc]initWithRootViewController:findCalngVC];
    findCalngVC.title=@"Find A Challenge";
    [self.navigationController pushViewController:findCalngVC animated:YES];

}

- (IBAction)btnCreatePressed:(id)sender {
    CreateChlng1ViewController *crtChlng1VC=[[CreateChlng1ViewController alloc]initWithNibName:@"CreateChlng1ViewController" bundle:nil];
    crtChlng1VC.title=@"Step 1";
    [self.navigationController pushViewController:crtChlng1VC animated:YES];

}
-(IBAction)btnHomePressed:(id)sender{

    if (!isOpen) {

        [self viewHomeOpenAnim];
        
        
    }else{
        [self viewHomeCloseAnim];
    }
     
}

- (IBAction)btnSettingPressed:(id)sender {
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationCurveEaseIn
                     animations:^{
                        
                         self.viewHome.frame = CGRectMake(0,-176, self.viewHome.frame.size.width,176);
                         isOpen=NO;
                     } completion:^(BOOL finished) {
                         [self.viewHome removeFromSuperview];
                         SettingViewController *settingVC=[[SettingViewController alloc]initWithNibName:@"SettingViewController" bundle:nil];
                         settingVC.title=@"Settings";
                         [self.navigationController pushViewController:settingVC animated:YES];
                     }];


}

- (IBAction)btnActivityPressed:(id)sender {
 
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationCurveEaseIn
                     animations:^{
                                                  self.viewHome.frame = CGRectMake(0,-176, self.viewHome.frame.size.width,176);
                         isOpen=NO;
                     } completion:^(BOOL finished) {
                         [self.viewHome removeFromSuperview];
                          activtyVC  =[[ActivityViewController alloc]initWithNibName:@"ActivityViewController" bundle:nil];
                         activtyVC.title=@"Activity";
                         [self.navigationController pushViewController:activtyVC animated:YES];
                     }];

}

-(IBAction)btnProfileAction:(id)sender{
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationCurveEaseIn
                     animations:^{
                       
                         self.viewHome.frame = CGRectMake(0,-176, self.viewHome.frame.size.width,176);
                         isOpen=NO;
                     } completion:^(BOOL finished) {
                         [self.viewHome removeFromSuperview];
                         ProfileViewController *profileVC=[[ProfileViewController alloc]initWithNibName:@"ProfileViewController" bundle:nil];
                         profileVC.title=@"Profile";
                         [self.navigationController pushViewController:profileVC animated:YES];
                     }];

}
-(void)viewHomeCloseAnim{
  
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationCurveEaseIn
                     animations:^{
                                                 self.viewHome.frame = CGRectMake(0,-176, self.viewHome.frame.size.width,176);
                         isOpen=NO;
                     } completion:^(BOOL finished) {
                                                  
                         [self.viewHome removeFromSuperview];
                         
                     }];
  }
-(void)viewHomeOpenAnim{
    
    [self.view addSubview:viewHome];
    viewHome.frame=CGRectMake(0, -176, self.viewHome.frame.size.width, 176);
    
 
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationCurveEaseIn
                     animations:^{
                         self.viewHome.frame = CGRectMake(0,0, self.viewHome.frame.size.width,176);
                         isOpen=YES;
                     } completion:^(BOOL finished) {
                         
                     }];
    
}
#pragma mark - own methods
-(void)setNavigationComponent{
    //Home Button
    //UIButton *btnleft=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 80, 40)];
    UIButton *btnleft=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnleft addTarget:self action:@selector(btnHomePressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnleft setFrame:CGRectMake(0, 0, 40, 44)];
    [btnleft setImage:[UIImage imageNamed:@"headerHome"] forState:UIControlStateNormal];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithCustomView:btnleft ];//]:[UIImage imageNamed:@"headerHome"] style:UIButtonTypeCustom target:self action:@selector(btnHomePressed:)];
    self.navigationItem.leftBarButtonItem = leftButton;
    //Tag Buttong
    //headerFit

    UIButton *btnFitTag=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnFitTag addTarget:self action:@selector(btnCreatePressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnFitTag setFrame:CGRectMake(0, 0, 40, 44)];
    [btnFitTag setImage:[UIImage imageNamed:@"headerFit"] forState:UIControlStateNormal];
    UIBarButtonItem *rightButton1 = [[UIBarButtonItem alloc] initWithCustomView:btnFitTag ];

    //heasderSearch
    UIButton *btnSearch=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnSearch addTarget:self action:@selector(btnFindPressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnSearch setFrame:CGRectMake(0, 0, 30, 44)];
    [btnSearch setImage:[UIImage imageNamed:@"headerSearch"] forState:UIControlStateNormal];
    UIBarButtonItem *rightButton2 = [[UIBarButtonItem alloc] initWithCustomView:btnSearch ];
    
    UIToolbar* toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 105.0f, 44.01f)];
    //For toolbar Background Transperent
    const float colorMask[6] = {222, 255, 222, 255, 222, 255};
    UIImage *img = [[UIImage alloc] init];
    UIImage *maskedImage = [UIImage imageWithCGImage: CGImageCreateWithMaskingColors(img.CGImage, colorMask)];
    [toolbar setBackgroundImage:maskedImage forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsDefault];
   // [toolbar setTintColor:[UIColor colorWithRed:204 green:0 blue:0 alpha:1]];
    
   // [toolbar setTranslucent:YES];
      NSArray* buttons = [NSArray arrayWithObjects:rightButton2, rightButton1, nil];
        [toolbar setItems:buttons animated:NO];
     self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:toolbar];
    
    //self.navigationItem.rightBarButtonItem = rightButton1;
    //TextField
    
}

-(void)viewHomeRemove{
    
    [self.viewHome removeFromSuperview];
    
}

@end
